#!/bin/bash
WRK=~/wrk2/wrk
AMCSSERVER='localhost:4444'
OUTDIR='results'
OUTFILE='get.log'
CONNECTIONS='50'
THREADS='4'
DURATION='30'
COUNTERS='10'

mkdir -p ${OUTDIR}
for i in 1 10 100 110 120 130 140 150 200; do
    CMD="${WRK} -s get.lua -c ${CONNECTIONS} -t ${THREADS} -d ${DURATION}s -R ${i}k http://${AMCSSERVER}/ -- ${COUNTERS} | tee -a ${OUTDIR}/${OUTFILE}"
    echo ${CMD} | tee -a ${OUTDIR}/${OUTFILE}
    bash -c "${CMD}"
done

