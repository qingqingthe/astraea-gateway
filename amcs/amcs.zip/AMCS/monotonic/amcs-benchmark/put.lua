uuid = require"uuid"

wrk.method = "PUT"

function init(args)
    uuids = {}
    index = 0

    if #args ~= 1 then
        print("Required argument: number of counters. Use -- after wrk command")
        os.exit()
    end

    if #uuids == 0 then
        uuid.randomseed(123);
        for i=1,args[1] do
            table.insert( uuids, uuid() )
            os.execute("curl -o /dev/null -s -X POST http://localhost:4444/monotonicCounter/" .. uuids[ #uuids ] .. "/counter")
        end
        print()
    end
end

request = function(args)
	local path = "/monotonicCounter/" .. uuids[1+index % #uuids] .. "/inc"
    index = index + 1
	return wrk.format(nil, path)
end

