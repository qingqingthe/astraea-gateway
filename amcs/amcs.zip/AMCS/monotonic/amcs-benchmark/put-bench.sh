#!/bin/bash
WRK=~/wrk2/wrk
AMCSSERVER='localhost:4444'
OUTDIR='results'
OUTFILE='put.log'
CONNECTIONS='50'
THREADS='4'
DURATION='30'
COUNTERS='10'

mkdir -p ${OUTDIR}
for i in 10 100 1000 2000; do
    CMD="${WRK} -s put.lua -c ${CONNECTIONS} -t ${THREADS} -d ${DURATION}s -R ${i} http://${AMCSSERVER}/ -- ${COUNTERS} | tee -a ${OUTDIR}/${OUTFILE}"
    echo ${CMD} | tee -a ${OUTDIR}/${OUTFILE}
    bash -c "${CMD}"
done

