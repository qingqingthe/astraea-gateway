#include <enclave_amcs_t.h>
#include <amcs_service.h>
#include <sgx_cryptoall.h>
#include <stdio.h>

//------------------------------------------------------------------------------
int printf(const char *fmt, ...) {
    char buf[BUFSIZ] = {'\0'};
    va_list ap;
    va_start(ap, fmt);
    int ret = vsnprintf(buf, BUFSIZ, fmt, ap);
    va_end(ap);
    ocall_print(buf);
    return ret;
}
//------------------------------------------------------------------------------

AMCS amcs;

//------------------------------------------------------------------------------
int ecall_addfile( const char *buff, size_t len ) {
    void *unsealed, *mactxt;
    int dlen;
    if( (dlen = unseal((const uint8_t*)buff, &unsealed, &mactxt, &len )) < 0 )
        return 1;
    int ret = amcs.input_file( std::string( (char*)unsealed, dlen ) );
    free( unsealed );
    free( mactxt );
    return ret;
}

//------------------------------------------------------------------------------
int ecall_query( int fd, const char *buff, size_t len ) {
    std::string response;
    amcs.process_input( response, buff, len );
    ocall_response( fd, response.c_str(), response.size() );
    return 0;
}

//------------------------------------------------------------------------------
int ecall_init() {
    return amcs.init();
}

//------------------------------------------------------------------------------
void ecall_update() {
    amcs.update_loop();
}

//------------------------------------------------------------------------------
void ecall_finish() {
    amcs.finish();
}

