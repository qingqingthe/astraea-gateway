#include <enclave_amcs_u.h>
#include <stdio.h>
#include <sys/socket.h>
#include <event_loop.h>
#include <fstream>

//------------------------------------------------------------------------------
void ocall_print( const char* str ) {
    printf("\033[96m%s\033[0m", str);
}

//------------------------------------------------------------------------------
extern std::condition_variable oqcv;
extern std::mutex oqmutex;
extern DataQueue oqueue;
void ocall_response( int fd, const char *buff, size_t len ) {
#if 0
    {
        std::lock_guard<std::mutex> lock(oqmutex);
        oqueue.push( std::make_pair(fd,std::string(buff,len)) );
    }
    oqcv.notify_one();
#else
    send( fd, buff, len, 0 );
#endif
}

//------------------------------------------------------------------------------
void ocall_persist( const char *name, const char *buff, size_t len ) {
    std::ofstream file(name);
    file.write( buff, len );
}

//------------------------------------------------------------------------------

