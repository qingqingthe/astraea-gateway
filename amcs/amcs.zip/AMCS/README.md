# AMCS
Asynchronous Monotonic Counter Implementation


# Get submodules
```
$ git submodule update --init --recursive
```

# Compile
```
$ make
```

# Benchmark
```
$ cd amcs-benchmark
$ mkdir -p results
$ ~/wrk2/wrk -s get.lua -c 50 -t 4 -d 30s -R 100k http://localhost:4444/ -- 10 | tee -a results/get.log
$ ~/wrk2/wrk -s put.lua -c 50 -t 4 -d 30s -R 60k http://localhost:4444/ -- 10 | tee -a results/put.log
```

